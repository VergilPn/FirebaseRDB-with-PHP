<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
</head>
<body>
    <form method="post" action="signup_action.php">
        <h2>SIGN UP FORM</h2><br>
        Full name<br>
        <input type="text" name="name"><br>
        Email<br>
        <input type="text" name="email"><br>
        Password<br>
        <input type="password" name="password"><br>
        <input type="submit" value="SIGN UP"><br><br>
        Already have an account? <a href="login.php">Login</a>
    </form>
</body>
</html>