<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form method="post" action="login_action.php">
        <h2>LOGIN FORM</h2><br>
        Email<br>
        <input type="text" name="email"><br>
        Password<br>
        <input type="password" name="password"><br>
        <input type="submit" value="LOGIN"><br><br>
        Don't have an account yet? <a href="signup.php">Sign Up</a>
    </form>
</body>
</html>