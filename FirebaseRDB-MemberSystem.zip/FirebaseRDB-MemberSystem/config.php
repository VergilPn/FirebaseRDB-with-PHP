<?php
session_start();
$databaseURL = "Your Firebase's Realtime Database URL";